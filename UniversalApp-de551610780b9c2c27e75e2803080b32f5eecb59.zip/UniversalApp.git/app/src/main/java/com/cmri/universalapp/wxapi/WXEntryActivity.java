package com.cmri.universalapp.wxapi;


/**
 * Created by ntop on 15/9/4.
 */
public class WXEntryActivity extends com.umeng.weixin.callback.WXCallbackActivity {

}
