package com.cmri.universalapp.mainmodule;

import android.content.Context;

/**
 * Created by susu on 2017-04-20.
 */

public interface IMainView {

    /**
     *
     */
    void openDrawer(int var1);
    /**
     *
     */
    Context getContext();
    /**
     *
     */
    void changeCitySuccess();
}
