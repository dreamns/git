<!--
感谢提交问题，提交 issue 前请先通过关键字搜索已经存在或解决了的 issue，避免重复提交相同内容。
issue应包含如下几个信息
1. 使用环境 (运行脚本中已包含自动识别功能，复制即可)
2. 遇到问题（如有可能，请详细描述，建议附上截图。不负责的 issue 可能会被 close）
3. 改进建议(可填)
具体实例如下，按照该例进行提交 issue
-->

**********
Screen: Physical size: 1080x2160
Density: Physical density: 400
Override density: 480
DeviceType: OS105
OS: darwin
Python: 2.7.13 |Anaconda 4.4.0 (x86_64)| (default, Dec 20 2016, 23:05:08)
[GCC 4.2.1 Compatible Apple LLVM 6.0 (clang-600.0.57)]
**********
遇到问题：（请说清楚自己遇到了啥问题，不然可能被 close。还没有自己机型配置文件的请自己去创建一个，好用的话欢迎 PR。）
![]()
改进和建议：无
